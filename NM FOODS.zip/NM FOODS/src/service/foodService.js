const Food = require("../models/food.model.js");

module.exports = {
    async createFood(req, restaurant) {
        try {
            const food = new Food({
                foodCategory: req.category,
                creationDate: new Date(),
                description: req.description,
                images: req.images,
                name: req.name,
                price: req.price,
                isSeasonal: req.isSeasonal,
                isVegetarian: req.isVegetarian,
                restaurant: restaurant._id,
                ingredients: req.ingredients,
            });
        }
    }

}