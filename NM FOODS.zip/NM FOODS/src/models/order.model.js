const mongoose = require('mongoose');

// Define the Order Schema
const OrderSchema = new mongoose.Schema({
    customer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    restaurant: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Restaurant',
    },
    totalAmount: Number,
    OrderStatus: String,
    createdAt: {
        type: Date,
        default: Date.now,
    },
    deliveryAddress: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Address",
    },
    items: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "OrderItem",
    }],
    totalItem: Number,
    totalPrice: Number,
});

// Define and export the Order model
const Order = mongoose.model('Oder', OrderSchema);
module.exports = Order; 