 const mongoose  = require("mongoose")
    
    const mongodbUrl="mongodb+srv://sathyadevinagarajan:0Gv7XDSgPq0sL0uY@cluster0.ryody.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

 async function connectDB(){
     return mongoose.connect(mongodbUrl)
 } 

 module.exports = connectDB  